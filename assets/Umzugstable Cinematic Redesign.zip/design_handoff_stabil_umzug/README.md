# Handoff: Stabil Umzug – Connected Umzug Planning System

## Overview
A bilingual (DE/EN) web system for Stabil Umzug (Essen): a family describes a move once on a phone, the company turns it into a personal offer (via WhatsApp/e-mail – no prices shown online), a schedule and a job for the crew. Three surfaces:
1. **Family flow** (mobile): Welcome + screens F1–F12 (start, access, rooms, items, review, services, insurance, summary, booking, timeline, moving day, after).
2. **Back office** (desktop): C1 lead inbox, C2 quote editor, C3 schedule, C4 master data, C5 rates, C6 reports.
3. **Crew** (desktop/tablet): K1 job list, K2 job check.

## About the Design Files
Files in this bundle are **design references created in HTML** (Design Components, *.dc.html). They are prototypes showing intended look and behaviour, not production code. Recreate them in the target codebase's environment (e.g. Next.js/React + a relational DB) using its established patterns. If no codebase exists yet, a mobile-first web app with a separate back-office route and one relational database is recommended.

## Fidelity
**High-fidelity.** Colours, type, spacing and copy are final per the Modernist design system. Estimator numbers (rates, buffers, vehicle capacities, item volumes) are placeholder planning values the company must replace via C4/C5.

## Design system – Modernist
Source: `_ds/styles.css` (tokens + component classes). Key tokens:
- Ground `--color-bg #f3f2f2`, surface `#eae9e9`, text `#201e1d`, accent `#ec3013` (ramps 100–900 in styles.css, e.g. accent-700 `#ae1800` for small accent text)
- Divider `color-mix(#201e1d 40%)`, strong rules 2px, row rules 1px
- Font: Archivo (400/600/800) for everything; headings weight 800, letter-spacing −0.015em
- Radius 0 everywhere. Spacing 4/8/12/16/24/32.
- Photographs always grayscale (`.grayscale`: grayscale(1) contrast(1.08))
- Buttons flush-left labels (`.btn-block` justify flex-start); primary = accent fill; focus = 2px accent outline
- Classes used: .btn(.btn-primary/.btn-secondary/.btn-ghost/.btn-block/.btn-icon), .tag(.tag-accent/.tag-neutral/.tag-outline), .input, .field, .seg/.seg-opt, .radio/.dot, .card(.card-kicker/.card-title/.elev-sm/.elev-md), .table, .nav/.nav-brand, .hr

## Brand assets (from stabilumzug.de)
- Logo: https://primary.jwwb.nl/public/n/u/w/temp-mupjujijfadhhmkiutgc/img_2835-high.jpg
- Transporter photo: https://primary.jwwb.nl/public/n/u/w/temp-mupjujijfadhhmkiutgc/8597fb76-7bf0-4586-802e-a59be04f8c63-high.jpg
- Branded illustration: `assets/stabil-scene.svg` (Sprinter-style van in livery + crew; no Mercedes star by design)
- Contact: Tel/WhatsApp 0163 9688190 (wa.me/491639688190), info.stabilumzug@gmail.com, Mo–Fr 9–19, Sa/So 9–17, contact Ibrahim Abdelaal
- Copy source: all DE/EN strings live in the `T` object in `Umzug Flow.dc.html` and `Umzug Backoffice.dc.html` – extract them into i18n JSON.

## Family flow screens (mobile 402×874 reference, fluid down to 360)
Shared shell: 12-cell progress strip (4px, accent = done), kicker "Schritt n von 12 · Title" (12px uppercase), "Entwurf gespeichert" indicator, scrollable body (padding 16, gap 18), sticky footer with 2px top rule, back icon button 48×48 + primary block button 48px. h2 30px/1.05 letter-spacing −0.02em; lead 15px neutral-700. All tap targets ≥44px.

- **Start (Welcome)**: dark hero (bg = text colour) with h1 34px (second line accent), lead, branded scene SVG on light panel, caption row; "So läuft Ihr Umzug" 4 numbered steps (number 24px accent); red poster band with logo + tagline; team/cartons cards (surface); Kundenstimme quote (17px/800); hours + phone 2-col strip; grayscale photo slot. CTA "Umzug planen".
- **F1 Start**: inputs old/new address (commit on blur), live route map (iframe `route-map.html?from&to&lang`, 200px, 2px border; Leaflet + OSM + Nominatim + OSRM; posts {type:'route',km,min} to parent → km field filled, tagged "live"), km input (manual override clears live), date mode seg (fixed/flexible), household seg (1/2/3–4/5+).
- **F2 Access**: per building (Auszug/Einzug): floor seg (EG/1–2/3–4/5+), lift seg (none/small/large/?), parking seg (door/≤30m/>30m/?); checkbox Halteverbotszone with plain-language hint.
- **F3 Rooms**: room rows (name, m² number input 60px, remove 44px); "skip" allowed; add-room chips for remaining rooms.
- **F4 Items** (key screen): 5-mode tab strip (Katalog/Vorlage/Schnell/Liste/Fotos, 44px, active = text bg).
  - A Catalogue: search input, room chips (active accent), rows with name + m³ + source tag, −/+ stepper (44px; + is accent), size variant seg (S/M/L or cm).
  - B Preset: household seg (1 Person/Paar/Familie) → "Vorlage übernehmen" adds default list, source=preset.
  - C Quick guess: per room seg Wenig/Mittel/Viel → expands to items, source=guess (re-pick replaces).
  - D List: textarea paste ("2 Sofas", "3x Stuhl"), "Liste abgleichen" → matched (tag list) + unmatched lines → "Als eigenen Gegenstand anlegen" card with L×B×H cm → volume computed.
  - E Photos: per room image slot (grayscale, 120×90) + "Vorschläge anzeigen" → proposals with confidence % and Ja/Nein 40px buttons; duplicate flag if item already present from another source.
  - Footer shows volume range + confidence label (Hoch/Mittel/Niedrig; colours text / accent-700 / accent).
- **F5 Review**: 3-col stat strip (items, m³ range, kg range), "Unsichere Einträge" list (source≠catalogue, tag-accent, link back), open lines banner (2px accent border), full list with source tags, export link.
- **F6 Services**: checkbox rows (22px square, accent when on) packing/assembly/kitchen/storage/disposal – no prices; tag "gewählt".
- **F7 Insurance**: declared value input (prefilled guess, tagged), 4 radio options (statutory – inklusive; transit/own/liability – auf Anfrage) each with plain cover text + exclusions (accent-700) + policy-number field where relevant; deadline note box.
- **F8 Summary** (no prices): accent block with volume range, confidence, "Angebot innerhalb von 24 Std."; 3-col strip (volume, vehicle, crew·hours); list of planned items (labour, vehicle, distance, assembly, access, packing, extras, insurance) as text values; "Warum diese Spanne?" details; low-confidence → video-check box. Footer: **WhatsApp** primary (wa.me link with prefilled summary), e-mail secondary (mailto), Weiter ghost.
- **F9 Booking**: summary grid (date, route, offer note), payment seg (Überweisung/Karte/Bar), documents list, cancellation terms box, terms checkbox gating "Jetzt buchen" (disabled until checked) → booked banner, goes to F10.
- **F10 Timeline**: checklist rows with deadline ("14 Tage vorher" / "14 Tage danach"); HVZ marked "Wir übernehmen" when chosen in F2.
- **F11 Moving day**: live map iframe with truck marker along route (`&progress=0..1`), 6-cell status strip + status list (current gets ETA tag), crew lead row (logo plate, name, vehicle, call button), damage note (photo slot + textarea) → "Notiert".
- **F12 After**: invoice row (date, tag Bezahlt), documents list, 5 square rating buttons (44px), claim button → claim box with deadline + "In Prüfung" tag.

## Back office (desktop; collapses to one column <~1000px)
Sidebar 220px, 2px right rule, logo, groups Büro/Crew, active item = text bg. Page header: kicker "Cx · Role", h2 28px, subtitle.
- **C1**: status filter chips with counts; `.table` (Nr, Haushalt, Strecke, Termin, m³, Vertrauen tag, Quelle, Status tag, Zuständig); row select → detail card (owner select, "Angebot öffnen", "Zuweisen").
- **C2**: version/master-data chip, editable rate inputs per line (right-aligned 90px), total row 2px rule, buttons manual line / approve / send; item list with source tags.
- **C3**: week grid 160px + 6 day columns; rows = trucks + crews; cells: booked (text bg), conflict (accent), tentative (outline).
- **C4**: toolbar (search, import/export, + item), wide table (item_id, name, room, m³ editable, kg, dis/asm min, carry crew, flags, version); review queue card for custom items ("Übernehmen"); version history card.
- **C5**: 4 rate groups (labour, vehicles, access, insurance) with effective dates, editable inputs + unit, audit note, discard/save.
- **C6**: quote-vs-actual bars per component (quoted neutral-400 under actual text bar, delta coloured accent if >10%); conversion table by source; damage/claims KPIs.
- **K1**: job cards (id·time, status tag, household, route, meta, special-item tag, contact, → Protokoll).
- **K2**: check-off list (22px squares), 3 damage photo slots, start/end time + km inputs, signature box 110px, "Auftrag abschließen".

## Estimator (business rules to implement server-side)
- volume = (1 + buffer 0.10) × Σ n·v; range ±8% (high) / ±18% (medium) / ±35% (low)
- confidence score = Σ n·w / Σ n with w: catalogue/custom 1, list/photo 0.6, preset/guess 0.2 → high ≥0.8, medium ≥0.5, else low
- vehicle = smallest of Sprinter 20 m³ / Koffer 7,5t 38 m³ / 12t 50 m³ covering volume, else trips of 7,5t; crew = max carry_crew (min 2), +1 at >30 m³, +1 at >45 m³
- hours = 0.25·vol + 0.22·vol + trips·(km/45)·2 + assembly/60/(crew−1) + access factor
- Prices are internal only (C2/C5); nothing is shown to the family.
- Master data item fields: see table in C4 and the `CAT` array in `Umzug Flow.dc.html`.

## Interactions
- All state client-side in the prototype (`Umzug Flow.dc.html` logic class). Production: autosave draft per request id, resume on any device.
- Map: route-map.html is a standalone page; swap OSRM/Nominatim for Google Maps Directions/Geocoding if an API key is available (same postMessage contract).
- WhatsApp handoff: `https://wa.me/491639688190?text=<encoded summary>`.

## Files
- `Umzug Flow.dc.html` – family flow shell, state, estimator, DE/EN strings
- `Umzug Screen.dc.html` – family flow screen templates (Welcome, F1–F12)
- `Umzug Backoffice.dc.html` – C1–C6, K1, K2
- `route-map.html` – live map (Leaflet/OSM/OSRM)
- `assets/stabil-scene.svg` – branded illustration
- `_ds/styles.css`, `_ds/readme.md` – Modernist tokens and component classes
- `support.js`, `image-slot.js`, `ios-frame.jsx` – prototype runtime helpers (not to be shipped)
